﻿var msg='Я строка из файла: 1.js';
alert(msg);
console.log(msg);
console.log('Реестр мест загрузок:',includeHTML('places'));

